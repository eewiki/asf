void foo()
{
abc(1,2,3);
abc(10,20,30);
abc(100,200,300);
cab(3,2,1,0);
brat("foo",2000,3000);
brat("question",2,-42);
brat("a",-22, 1);
}
