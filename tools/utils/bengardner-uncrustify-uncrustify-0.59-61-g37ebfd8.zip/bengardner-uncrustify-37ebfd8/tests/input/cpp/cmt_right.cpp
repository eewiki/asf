class X
{
    struct Zone
    {
        //    int a;
        //    int b;
        int c;
        int d;
        double e;
        inline Zone(int _c) : c(_c)
        { }                                     // constructor for zone search

        inline Zone(
            //int _a,
            //int _b,
            int _c,
            int _d, double _e) :
            //a(_a),
            //b(_b),
            c(_c),
            d(_d),
            e(_e)
        { }
    };
};

