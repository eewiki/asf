class C
{
public:
A* B;
C& D;
const C& D;
static C& D;
public C& D;
E=C& D;
};

