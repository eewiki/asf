
#define foobar(x) \
{ \
for (i=0; i < x; i++) \
{ \
junk(i,x); \
} \
}

