int main()
{
   mWriter( "class Clst_"c )( cluster.getChild( HO_SHORT_NAME ).getText() )( " : Cluster {"c ).newline;
}

