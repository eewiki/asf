void f()
{
for ( ; it != Values.end(); ++it)
BTree.insert(std::pair < int, double > (*it, double (*it) + 1.0));


for ( ; vIt != Values.end(); ++vIt)
{ }
for ( ; vIt != Values.end(); ++vIt)
{ }

for ( ; ; ) ;
for (int i = 0; i < 42; ) i += 3;

for (int i = 0; i < 42; ++i) k += 3;
}

