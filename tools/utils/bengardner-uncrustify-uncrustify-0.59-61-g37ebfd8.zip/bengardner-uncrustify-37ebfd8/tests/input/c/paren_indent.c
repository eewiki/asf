function1
(something1);

function2
      (something2);

x = (float)
(number);

x = (float)
     (number);

