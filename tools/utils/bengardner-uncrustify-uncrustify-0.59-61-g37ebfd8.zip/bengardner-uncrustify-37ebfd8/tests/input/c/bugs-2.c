static void tcps_proc_server_msg(void *p_user, const ptc_msg_info_t *p_info)
{
   if (z)
   {
      if (a)
      /* comment */
      {
         a++;
      }
      /* comment */
      else if (b)
      {
         b++;
      }
      /* Comment */
      else
      {
         c++;
      }
   }
}

