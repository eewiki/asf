void f () { g ("\
");
  g ("\n", stdout);
}
