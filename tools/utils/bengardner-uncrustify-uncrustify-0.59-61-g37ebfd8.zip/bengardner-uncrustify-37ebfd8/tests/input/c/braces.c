
void foo(void)
{
   int a = 0;
   while (a < 3)
   {
      a++;
   }

   while (b < a)  // trailing C++ comment
      b++;

   do  // trailing C++ comment
   {
      a--;
   } while (a > 0);

   do
      a--;
   while (a > 0);

   for (a = 0; a < 10; a++) // trailing C++ comment
   {
      printf("a=%d\n", a);
   }

   if (a == 10)  // trailing C++ comment
   {
      printf("a looks good\n");
   }
   else // trailing C++ comment
   {
      printf("not so good\n");
   }

   if (state == ST_RUN)
   {
      if ((foo < bar) &&
          (bar > foo2))
      {
         if (a < 5)
         {
            a *= a;
         }
         else if (b != 0)
            a /= b;
         else // trailing C++ comment
            a += b;
      }
   }

   list_for_each(k) {
      if (a)
         if (b)
         {
            c++;
         }
   }


   while (1)
      ;  /* hang forever */
}

void f() {
  if (buf[0] == '~' && strchr(tmp, '/') == NULL) {
    buf = mallocstrcpy(buf, tmp);
    matches = username_tab_completion(tmp, &num_matches);
  }
  /* If we're in the middle of the original line, copy the string
  only up to the cursor position into buf, so tab completion
  will result in buf's containing only the tab-completed
  path/filename. */
  else if (strlen(buf) > strlen(tmp))
    buf = mallocstrcpy(buf, tmp);
}

void f() {} void g() {}

