unsigned int align_here();
int this_works(int x);
int bug(int); // BUG: left-aligned

