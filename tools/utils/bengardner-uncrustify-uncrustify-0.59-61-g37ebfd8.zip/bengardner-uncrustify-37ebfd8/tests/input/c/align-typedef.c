
typedef int MY_INT;
typedef int * MY_INTP;
typedef int(*foo_t)(void *bar);
typedef int(*somefunc_t)(void *barstool);
typedef int int8_t __attribute__((__mode__(__QI__)));
typedef int uint8_t;
typedef struct _IDirectFBSurface         IDirectFBSurface;
typedef struct _IDirectFBPalette         IDirectFBPalette;
typedef struct timezone *__restrict   __timezone_ptr_t;

