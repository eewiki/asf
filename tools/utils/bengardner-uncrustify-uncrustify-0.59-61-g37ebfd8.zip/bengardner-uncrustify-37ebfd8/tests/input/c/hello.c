#include <stdio.h>

void HelloWorld(char* pString)
{
    printf("%s\n", pString);
} /* HelloWorld */

int main()
{
    HelloWorld("Hello world");
    
    return 0;
} /* main */
