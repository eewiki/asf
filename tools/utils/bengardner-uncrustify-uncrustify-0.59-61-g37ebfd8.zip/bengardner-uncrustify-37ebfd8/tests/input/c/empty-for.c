void foo(void)
{
   for (;x<2;x++)
   {
   }
}
