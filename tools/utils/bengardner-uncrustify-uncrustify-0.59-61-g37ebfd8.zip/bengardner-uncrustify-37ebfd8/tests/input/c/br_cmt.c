int main()
{
	if( foo == bar )
	{ /* this works */
                a;
	}else
    if( ranz != bar )
	{ /* this works too */
                b;
	}else
	{ /* this is broken */
        c;
	}
}
