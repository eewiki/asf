
void foo(void)
{
p[0].x = x + (rx * cos(rs));
p[0].y = y - (ry * sin(rs));
}

