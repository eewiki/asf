int doStuff(int   i,
            float f );

int doStuff(int i,
      float f );


MACRO_MODIFIER int doStuff(int   i,
                 float f );

typedef void (*my_callback)(int id,
void *context);
