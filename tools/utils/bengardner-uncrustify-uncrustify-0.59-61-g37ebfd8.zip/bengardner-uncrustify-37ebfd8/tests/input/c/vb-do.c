
struct beef a =
{
   1, 2, 3
};

void get_name(void)
{
   int _ = 3;
   do
      a--;
   while (a);

   while (a) //something
      a--;

   do
      while (a) //something
         a--;
   while (b--);
}

