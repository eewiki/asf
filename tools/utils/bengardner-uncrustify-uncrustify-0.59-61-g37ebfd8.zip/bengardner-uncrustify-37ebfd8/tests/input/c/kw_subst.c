#include <string>

int foo1()
{
}

/** header comment */
#if 2
int foo2(void)
{
}
#endif

#if 1
void foo3(int a)
{
}
#endif

void *foo4(int a, int b, int c)
{
}
