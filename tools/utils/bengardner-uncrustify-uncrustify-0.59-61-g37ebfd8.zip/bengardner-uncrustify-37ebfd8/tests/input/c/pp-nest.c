#if AA
int foo() {
   #if BB
#else
    #if CC
 #else
      #endif
   #endif
}
  #endif

int bar()
{
}

